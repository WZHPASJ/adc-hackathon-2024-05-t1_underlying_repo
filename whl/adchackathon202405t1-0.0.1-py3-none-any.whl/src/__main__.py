import argparse
import sys
import os
from pyspark.sql import SparkSession
from src.transformations import DataTransformation
from src.config import ArgosConfig, TestConfig

sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))

# Creating a parser and reading CLI argument "process" to a variable
parser = argparse.ArgumentParser()
parser.add_argument("--user_input", type=str, required=True)
parser.add_argument("--underlying_repo", type=str, required=True)


# args = parser.parse_args(shlex.split(" ".join(sys.argv[1:])))

user_input = args.user_input
underlying_repo = args.underlying_repo

print(f"User input: {user_input}")
